# Manifest

Package: `round-5-polished-version-self-contained`

Created from the Round 5 polished layout prototype in the portfolio workspace.

Files:

- `index.html`
- `README.md`
- `MANIFEST.md`
- `assets/gen-pure-forms-grid.jpg`
- `assets/gen-slices.jpg`
- `assets/vision-o-dash-ui.jpg`
- `assets/vision-o-console.jpg`

External dependencies:

- None.
