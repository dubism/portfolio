# Round 5 Polished Version

Self-contained export of the portfolio prototype titled **R5-A Polished Continuous Stack**.

## How to Open

Open `index.html` directly in a browser. No dev server, package install, or internet connection is required.

## Contents

- `index.html` - the standalone prototype page with embedded CSS and JavaScript.
- `assets/` - the four local images used by the prototype.

## Source

Exported from:

`site/.review/layout-variants-round5/r5-a-polished-stack.html`

Original image sources:

- `site/public/review-assets/gen-pure-forms-grid.jpg`
- `site/public/review-assets/gen-slices.jpg`
- `site/public/review-assets/vision-o-dash-ui.jpg`
- `site/public/review-assets/vision-o-console.jpg`

## Notes

This package is intentionally isolated from the Next.js app. It preserves the Round 5 prototype behavior, including the theme switcher, scroll-driven image stack, parallax motion, squircle clipping, and caption transitions.
